function [solution, score, alternativeScores] = ahp(criteriaWeights, alternativeCriteriaRates)

% analytic hierarchy process 
% criteriaWeights: array of the criterias' weights -> array[criteriaNum] =
% criteria weight
% alternativeCriteriaRates: array[alternative number] = (array[criteriaNum] =
% alternative rate)
% returns - number of selected alternative

    % get numbers of criterias and alternatives
    criteriaNum = size(criteriaWeights, 2);
    alternativeNum = size(alternativeCriteriaRates, 1);

    % array[criteria] = array[alternativeNum] = counted weight (rows - w^i) 
    criteriaAlternativeWeightVectorArray = zeros(criteriaNum, alternativeNum);

    % iterate on criterias    
    for criteria = 1:criteriaNum    

        pairComparisonMatrix = zeros(alternativeNum, alternativeNum);

        % fill the pair comparison matrix
        for alternative1 = 1:alternativeNum
            for alternative2 = 1:alternativeNum
                
                % get alternatives' rates on current criteria
                rate1 = alternativeCriteriaRates(alternative1, criteria);         
                rate2 = alternativeCriteriaRates(alternative2, criteria);

                rate = rate1 / rate2;

                pairComparisonMatrix(alternative1, alternative2) = rate;

            end
        end

        % matrix normalization
        for alternative = 1:alternativeNum
                          
            sum = 0;
            for row = 1:alternativeNum
                sum = sum + pairComparisonMatrix(row, alternative);
            end

            for row = 1:alternativeNum
                pairComparisonMatrix(row, alternative) = pairComparisonMatrix(row, alternative) / sum;
            end
        end

        criteriaWeight = criteriaWeights(criteria);

        %find score by criteria for alternatives
        for alternative = 1:alternativeNum

            alternativeVector = pairComparisonMatrix(alternative, :);

            score = mean(alternativeVector);
            weightedCriteria = score * criteriaWeight;

            criteriaAlternativeWeightVectorArray(criteria, alternative) = weightedCriteria;

        end        
    end

    alternativeScores = zeros(1, alternativeNum);    

    for alternative = 1:alternativeNum

        score = 0;

        for criteria = 1:criteriaNum
            score = score + criteriaAlternativeWeightVectorArray(criteria, alternative);
        end

        alternativeScores(alternative) = score;
    end

    %disp(alternativeScores);
    
    [score, solution] = max(alternativeScores);
end